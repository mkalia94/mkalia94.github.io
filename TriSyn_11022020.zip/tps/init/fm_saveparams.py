from tps import *
def saveparams(fm):
    if fm.savematlabpar:
        savematlabpar(fm)
